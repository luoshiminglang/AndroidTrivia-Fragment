/*
 * CIS 217      Android Development
 * Week 8 --    2.4 Data-binding basics
 * Instructor:
 * Student:   Lang Luo
 *
 */

package com.example.android.aboutme


// Create data class MyName for the name and nickname here.
data class MyName(var name: String = "", var nickname: String = "")